#!/bin/bash
aws_mfa_profile="mfa"
VPC_REGION="ap-southeast-1"
VPC_AZ="ap-southeast-1a"

## VPC Creation ##
VPC_ID=`aws ec2 create-vpc --cidr-block 10.0.0.0/16 --region $VPC_REGION --profile $aws_mfa_profile --query Vpc.VpcId --output text`
echo "VPC ID is $VPC_ID"


## Private Subnet Creation ##
aws ec2 create-subnet --vpc-id $VPC_ID --region $VPC_REGION --availability-zone $VPC_AZ --profile $aws_mfa_profile --cidr-block 10.0.1.0/24 \
--tag-specifications 'ResourceType=subnet,Tags=[{Key=Name,Value=my-private-subnet}]'
priv_subnet_id=`aws ec2 describe-subnets --filters Name=tag:Name,Values=my-private-subnet --query 'Subnets[*].SubnetId' --region $VPC_REGION --output text`
echo "Private Subnet id is $priv_subnet_id"

## Public Subnet Creation ##
aws ec2 create-subnet --vpc-id $VPC_ID --region $VPC_REGION --availability-zone $VPC_AZ --profile $aws_mfa_profile --cidr-block 10.0.2.0/24 \
--tag-specifications 'ResourceType=subnet,Tags=[{Key=Name,Value=my-public-subnet}]'
pub_subnet_id=`aws ec2 describe-subnets --filters Name=tag:Name,Values=my-public-subnet --query 'Subnets[*].SubnetId' --region $VPC_REGION --output text`
echo "Public Subnet id is $pub_subnet_id"

## Internet Gateway Creation ##
aws ec2 create-internet-gateway --profile $aws_mfa_profile --region $VPC_REGION --tag-specifications 'ResourceType=internet-gateway,Tags=[{Key=Name,Value=my-igw}]'
IGW_ID=`aws ec2 describe-internet-gateways --profile $aws_mfa_profile --region $VPC_REGION --filter Name="tag-value ",Values="my-igw" | grep -i InternetGatewayId | awk '{print $2}' | awk -F"," '{print $1}' | sed 's/\"//g'`
aws ec2 attach-internet-gateway --internet-gateway-id $IGW_ID --vpc-id $VPC_ID --region $VPC_REGION
echo "Internet Gateway ID is $IGW_ID"

## EIP and NAT Gateway Creation ##
aws ec2 allocate-address --domain vpc --region $VPC_REGION
eip_allocation_id=`aws ec2 describe-addresses --region $VPC_REGION --query 'Addresses[*].AllocationId' --output text`
aws ec2 create-nat-gateway --subnet-id $pub_subnet_id --allocation-id $eip_allocation_id --region $VPC_REGION --tag-specifications 'ResourceType=nat-gateway,Tags=[{Key=Name,Value=my-ngw}]'
NGW_ID=`aws ec2 describe-nat-gateways --profile $aws_mfa_profile --region $VPC_REGION --filter Name="tag-value ",Values="my-ngw" | grep -i NatGatewayId | awk '{print $2}' | awk -F"," '{print $1}' | sed 's/\"//g'`
echo "NAT Gateway ID is $NGW_ID"

## Private Route Table and Route Creation ##
aws ec2 create-route-table --vpc-id $VPC_ID --region $VPC_REGION --tag-specifications 'ResourceType=route-table,Tags=[{Key=Name,Value=my-priv-rtb}]'
PRIV_RTB_ID=`aws ec2 describe-route-tables --filters Name=tag:Name,Values=my-priv-rtb --query 'RouteTables[*].RouteTableId' --region $VPC_REGION --output text`
aws ec2 create-route --route-table-id $PRIV_RTB_ID --destination-cidr-block 0.0.0.0/0 --gateway-id $NGW_ID --region $VPC_REGION

## Public Route Table and Route Creation ##
aws ec2 create-route-table --vpc-id $VPC_ID --region $VPC_REGION --tag-specifications 'ResourceType=route-table,Tags=[{Key=Name,Value=my-pub-rtb}]'
PUB_RTB_ID=`aws ec2 describe-route-tables --filters Name=tag:Name,Values=my-pub-rtb --query 'RouteTables[*].RouteTableId' --region $VPC_REGION --output text`
aws ec2 create-route --route-table-id $PUB_RTB_ID --destination-cidr-block 0.0.0.0/0 --gateway-id $IGW_ID --region $VPC_REGION

## Public and Private Subnet Association to Route Tables ##
aws ec2 associate-route-table --route-table-id $PUB_RTB_ID --subnet-id $pub_subnet_id --region $VPC_REGION
aws ec2 associate-route-table --route-table-id $PRIV_RTB_ID --subnet-id $priv_subnet_id --region $VPC_REGION

## Security Group Creation for 2 EC2 Instances ##
aws ec2 create-security-group --group-name ec2-test1-allow --description "Security group for EC2 Test 1" --vpc-id $VPC_ID --region $VPC_REGION --tag-specifications 'ResourceType=security-group,Tags=[{Key=Name,Value=sg-ec2-test1-allow}]'
aws ec2 create-security-group --group-name ec2-test2-deny --description "Security group for EC2 Test 2" --vpc-id $VPC_ID --region $VPC_REGION --tag-specifications 'ResourceType=security-group,Tags=[{Key=Name,Value=sg-ec2-test2-deny}]'

SG_TEST1_ID=`aws ec2 describe-security-groups --filters Name=tag:Name,Values=sg-ec2-test1-allow --query 'SecurityGroups[*].GroupId' --region $VPC_REGION --output text`
SG_TEST2_ID=`aws ec2 describe-security-groups --filters Name=tag:Name,Values=sg-ec2-test2-deny --query 'SecurityGroups[*].GroupId' --region $VPC_REGION --output text`

aws ec2 authorize-security-group-ingress --group-id $SG_TEST1_ID --protocol all --port all --cidr 0.0.0.0/0 --region $VPC_REGION
aws ec2 authorize-security-group-ingress --group-id $SG_TEST2_ID --protocol tcp --port 22 --cidr 0.0.0.0/0 --region $VPC_REGION

## EC2 SSH Key Pair Creation ##
aws ec2 create-key-pair --key-name ssh-keyPair --query 'KeyMaterial' --output text > ssh-keyPair.pem --region $VPC_REGION --tag-specifications 'ResourceType=key-pair,Tags=[{Key=Name,Value=ssh-keyPair}]'
chmod 400 ssh-keyPair.pem

## Creation of two EC2 Instances in Public Subnets ##
aws ec2 run-instances --image-id ami-06b79cf2aee0d5c92 --instance-type t2.micro --count 1 --subnet-id $pub_subnet_id --security-group-ids $SG_TEST1_ID --associate-public-ip-address --key-name ssh-keyPair --region $VPC_REGION --tag-specifications 'ResourceType=instance,Tags=[{Key=Name,Value=ec2-test1}]'
aws ec2 run-instances --image-id ami-06b79cf2aee0d5c92 --instance-type t2.micro --count 1 --subnet-id $pub_subnet_id --security-group-ids $SG_TEST2_ID --associate-public-ip-address --key-name ssh-keyPair --region $VPC_REGION --tag-specifications 'ResourceType=instance,Tags=[{Key=Name,Value=ec2-test2}]'
